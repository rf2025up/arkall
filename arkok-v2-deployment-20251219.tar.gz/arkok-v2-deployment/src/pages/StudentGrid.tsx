export function StudentGrid() {
  return (
    <div className="p-4">
      <div className="text-center py-12">
        <div className="text-6xl mb-4">👥</div>
        <h1 className="text-2xl font-bold text-gray-800 mb-2">学生管理</h1>
        <p className="text-gray-600">此功能正在开发中...</p>
      </div>
    </div>
  );
}

export default StudentGrid;