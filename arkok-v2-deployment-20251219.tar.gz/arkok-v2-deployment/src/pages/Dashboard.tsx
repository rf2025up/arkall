export default function Dashboard() {
  return (
    <div>
      <h1>I AM THE OLD DASHBOARD - IF YOU SEE ME, IT IS A CACHE ISSUE</h1>
    </div>
  );
}