# ArkOK V2 备课与过关核心技术白皮书 (2025-12-19)

## 1. 核心设计哲学 (宪法适配)
本模块严格遵循《ArkOK V2 开发宪法》，旨在实现“一次发布，全端同步；动态路由，严禁硬编码”的极致教学体验。

### 1.1 数据模型一致性
- **复数命名**: 数据库表统一使用 `lesson_plans` (备课计划) 和 `task_records` (任务记录)。
- **ID 规范**: 所有新记录生成时，必须由后端注入 `randomUUID` (UUID v4)，严禁依赖数据库自增 ID。
- **时间规范**: 统一采用北京时间 (UTC+8)，更新操作必须手动注入 `updatedAt: new Date()`。

---

## 2. 备课发布逻辑 (Teacher Prep Flow)

### 2.1 师生绑定投送
- **范围锁定**: 任务不再按“班级”盲目投送，而是严格基于 `students.teacherId === currentUserId` 的绑定关系进行分发。
- **安全性**: 校长 (ADMIN) 禁止执行发布操作，必须切换至具体教师身份，以防止数据污染。

### 2.2 发布覆盖机制 (Override Logic) 🆕
- **单日覆盖**: 老师在同一天 (`YYYY-MM-DD`) 多次发布时，系统执行以下原子操作：
  1. **清理**: 使用 `deleteMany` 删除当日该老师为对应学生发布的所有 `isOverridden: false` 的旧记录。
  2. **注入**: 创建全新的任务记录，关联最新的 `lessonPlanId`。
- **保护机制**: 手动调整过的记录 (`isOverridden: true`) 将被保留，不会被二次发布覆盖。

### 2.3 进度快照同步
- **物理同步**: 发布成功后，系统会立即更新 `students` 表中的 `currentUnit`、`currentLesson` 和 `currentLessonTitle` 字段。
- **业务价值**: 确保过关页的学生列表视图能够实时反映最新的教学进度，无需二次计算。

---

## 3. 过关质检逻辑 (Student QC Flow)

### 3.1 动态节点生成
- **无硬编码**: 任务记录中的 `unit` 和 `lesson` 字段由发布时的 `courseInfo` 动态注入。
- **聚合展示**: 个人详情页根据 `task_records` 的 `type === 'QC'` 自动聚合生成全学期进度地图。

### 3.2 状态流转协议
- **PATCH 接口**: 统一使用 `PATCH /api/lms/records/:recordId/status` 进行状态更新。
- **状态定义**:
  - `PENDING`: 待处理/未过关
  - `COMPLETED`: 已过关 (前端视觉呈现为绿色 PASSED)
- **动作触发**:
  - `recordAttempt`: 每次点击“辅导”按钮，`attempts` 计数自增，记录教师的服务过程。
  - `toggleQCPass`: 点击勾选框，状态在 `PENDING` 和 `COMPLETED` 间切换。

---

## 4. 全局字段与接口规范

### 4.1 核心字段定义
| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| `className` | String | 统一使用 `className` 而非 `class_name` 或 `grade` |
| `recordId` | UUID | 前端 Task 对象必须携带 `recordId` 字段以支持状态回传 |
| `isOverridden` | Boolean | 标记记录是否由老师手动修改，用于保护数据不被自动覆盖 |
| `educationalDomain` | String | 教育维度分类（核心教学法/综合成长/基础作业） |

### 4.2 API 调用标准
- **封装优先**: 前端禁止使用原生 `fetch`，必须使用 `apiService`。
- **异常透明**: 所有 `apiService` 调用必须包含 `try-catch` 块，并使用 `alert` 或 `Toast` 弹出 `response.message`，严禁静默失败。
- **CORS 授权**: 后端必须显式授权 `PATCH` 方法，允许 `Content-Type` 和 `Authorization` 请求头。

---

## 5. 技术链路审计图
`备课页输入` -> `后端 publishPlan` -> `删除当日旧 task_records` -> `创建新 task_records` -> `更新 students 快照` -> `过关页 apiService.get 获取记录` -> `apiService.patch 修改状态` -> `数据库 update 实时生效`
