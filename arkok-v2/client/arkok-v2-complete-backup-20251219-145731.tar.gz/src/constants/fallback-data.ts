export const DEFAULT_FALLBACK_TASK_LIBRARY = {
  "基础核心": [
    { name: "完成数学作业", exp: 5 },
    { name: "完成语文作业", exp: 5 }
  ]
} as const;